The "byte_ascii.fon" is the bitmap fonts of ASCII, size: 12*24

The "word_unicode.fon" is the bitmap fonts of UTF-16, size: 24*24

Scan direction: form UP to DOWN, from LEFT to RIGHT
